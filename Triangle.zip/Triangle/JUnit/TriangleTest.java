import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class TriangleTest {

	private Triangle tri;
	@Before
	public void setUp() throws Exception {
		tri = new Triangle(0, 0, 0);
	}

	@Test
	public void test() {
		assertEquals("Illegal",tri.getType(new Triangle(0, 2, 3)));
		assertEquals("Illegal",tri.getType(new Triangle(333333333, 2, 3)));
		assertEquals("Regular",tri.getType(new Triangle(2, 2, 2)));
		assertEquals("Scalene",tri.getType(new Triangle(3, 4, 5)));
		assertEquals("Isosceles",tri.getType(new Triangle(3, 3, 5)));
	}

}
