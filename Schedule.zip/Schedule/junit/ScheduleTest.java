import java.util.ArrayList;
import java.util.List;

import org.junit.Before;
import org.junit.Test;

public class ScheduleTest {
	private Work w1; 
	private Work w2; 
	private Work w3; 
	Schedule schedule;
	@Before
	public void setUp(){
		schedule = new Schedule();
		
		w1 = new Work("work1", 2, 5);
		w2 = new Work("work2", 3, 4);
		w3 = new Work("work3", 7, 9);
	}
	@Test
	public void test(){

		
		List<Work> works = new ArrayList<Work>();
		works.add(w1);
		works.add(w2);
		works.add(w3);
		
		List<Double> FCFS = new ArrayList<Double>();
		List<Double> SJF = new ArrayList<Double>();
		FCFS = schedule.FCFS(works);
		SJF = schedule.SJF(works);
		
		List<Work> results = schedule.sortByServiceTime(works);
		
	}
}
