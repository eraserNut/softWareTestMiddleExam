import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;


public class SortingTest {

	private Sorting sort;
	int[] array;
	int[] newArray;
	Integer[] a = new Integer[]{4,2,3,1,6,5,7,9,8,10,12,11,13,14};
	@Before
	public void setUp() throws Exception {
		sort = new Sorting();
		array = new int[]{4,2,3,1,6,5,7,9,8,10,12,11,13,14};
		newArray = new int[]{0,0,0,0,0,0,0,0,0,0,0,0,0,0};
	}

	@Test
	public void test() {
		newArray = array;
		sort.insertionSort(newArray);
		assertTrue(sort.isSorted(newArray));
		
		newArray = array;
		sort.quicksort(newArray);
		assertTrue(sort.isSorted(newArray));
		
		newArray = array;
		sort.quicksort(newArray, 2, 13);
		
		newArray = array;
		sort.insertionSort(newArray, 2, 13);
		
//		newArray = array;
		sort.swapReferences(a, 2, 5);
		

		
		

	}

}
